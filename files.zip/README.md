# Orçamento de Obra — Excel Add-in

Painel lateral para Excel que lê sua planilha de orçamento, exibe fornecedores por categoria, permite selecionar o melhor preço e exportar resultados sem sair do Excel.

---

## Arquivos do projeto

```
orcamento-addin/
├── manifest.xml       ← registro do add-in no Office
├── taskpane.html      ← toda a UI + lógica (arquivo único, sem build)
├── assets/
│   ├── icon-16.png    ← ícone 16×16 px
│   ├── icon-32.png    ← ícone 32×32 px
│   └── icon-80.png    ← ícone 80×80 px
└── README.md
```

---

## Pré-requisitos

| Plataforma | Versão mínima |
|---|---|
| Excel para Windows | Microsoft 365 / Office 2019+ |
| Excel para Mac | Microsoft 365 |
| Excel Online | Qualquer |

---

## Opção A — Hospedagem gratuita no GitHub Pages (recomendada para testes)

1. Crie um repositório público no GitHub (ex.: `orcamento-addin`).
2. Faça upload de todos os arquivos da pasta `orcamento-addin/`.
3. Vá em **Settings → Pages → Branch: main / root** e salve.
4. Sua URL base será:
   ```
   https://SEU-USUARIO.github.io/orcamento-addin/
   ```
5. No `manifest.xml`, substitua **todas** as ocorrências de
   `https://SEU-DOMINIO.com/addin`
   por
   `https://SEU-USUARIO.github.io/orcamento-addin`

> **IMPORTANTE:** O Office exige HTTPS. GitHub Pages já fornece isso automaticamente.

---

## Opção B — Servidor próprio / Azure Static Web Apps / Netlify

1. Suba os arquivos para o host de sua preferência.
2. Certifique-se de que o servidor envia o header:
   ```
   Access-Control-Allow-Origin: *
   ```
3. Substitua `https://SEU-DOMINIO.com/addin` no manifest pela URL real.

---

## Configurar um GUID único

Abra `manifest.xml` e substitua o valor dentro de `<Id>`:

```xml
<Id>COLE-SEU-GUID-AQUI</Id>
```

Gere um GUID em: https://guidgenerator.com (formato: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

---

## Instalar no Excel

### Excel Online (mais rápido para testar)

1. Abra qualquer planilha em https://excel.office.com
2. **Inserir → Suplementos → Meus Suplementos → Carregar Suplemento**
3. Cole a URL direta do `manifest.xml` hospedado  
   ex.: `https://SEU-USUARIO.github.io/orcamento-addin/manifest.xml`

### Excel Desktop (Windows)

#### Via rede compartilhada (sem necessidade de publicação)

1. Coloque a pasta `orcamento-addin` em um caminho de rede acessível  
   ex.: `\\servidor\addins\orcamento-addin`  
   ou em uma pasta local para testes rápidos: `C:\addins\orcamento-addin`
2. No Excel: **Arquivo → Opções → Central de Confiabilidade → Configurações → Catálogos de Suplementos Confiáveis**
3. Adicione o caminho da pasta como catálogo (ex.: `\\servidor\addins\orcamento-addin`)
4. Marque **Mostrar no Menu** e clique **OK**
5. Reinicie o Excel
6. **Inserir → Meus Suplementos → PASTA COMPARTILHADA → Orçamento de Obra**

#### Via Microsoft AppSource (produção)

Siga: https://learn.microsoft.com/pt-br/office/dev/add-ins/publish/publish

---

## Formato esperado da planilha

O add-in lê a **aba ativa** esperando:

| Coluna | Índice (0-based) | Conteúdo |
|--------|-----------------|---------|
| C | 2 | Nome da categoria |
| D | 3 | Nome do fornecedor |
| F | 5 | Valor (número) |
| H | 7 | Status (`RECEBIDO` / `AGUARDANDO` / `NÃO SOLICITADO`) |
| J | 9 | Observações (texto livre) |

O parser ignora linhas sem status reconhecido e linhas de cabeçalho automaticamente.

---

## O que o add-in faz

| Funcionalidade | Como usar |
|---|---|
| Ler planilha | Abre automaticamente ao carregar |
| Busca | Campo de texto no topo do painel |
| Filtrar por status | Botões Todos / Recebidos / Aguardando |
| Ver detalhe | Clique em qualquer fornecedor |
| Editar valor/status/obs | Botão "Editar" no painel de detalhe — salva diretamente na célula |
| Selecionar fornecedor | Botão "Selecionar" no painel de detalhe |
| Comparar | Aba "Comparar" no painel de detalhe |
| Notas por categoria | Aba "Nota" no painel de detalhe |
| Barra de progresso | Quantas categorias já têm fornecedor selecionado |
| Exportar → aba "Selecionados" | Modal Exportar → "Criar aba Selecionados" |
| Exportar → aba completa | Modal Exportar → "Criar aba completa" |
| Baixar .xlsx | Modal Exportar → "Baixar .xlsx" |
| Baixar .csv | Modal Exportar → "Baixar .csv" |

---

## Ícones (opcional mas recomendado)

Crie PNGs simples (fundo verde `#1A3820`, ícone branco de planilha) nos tamanhos 16, 32 e 80 px e coloque em `assets/`. Se não tiver ícones, o Office usará um ícone genérico — o add-in funciona normalmente.

---

## Problemas comuns

| Sintoma | Solução |
|---|---|
| "Formato não reconhecido" | Verifique se as colunas C, D, F, H, J estão corretas |
| Painel não abre | Confirme que a URL do manifest bate com a URL real do taskpane.html |
| "HTTPS required" | O Office bloqueia HTTP; use GitHub Pages ou similar |
| Erro de CORS | Configure `Access-Control-Allow-Origin: *` no servidor |
| Add-in não aparece no menu | Feche e reabra o Excel depois de adicionar o catálogo |
